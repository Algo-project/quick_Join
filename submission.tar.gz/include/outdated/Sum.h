/*For getting the final result*/
#pragma once
#include "Query.h"
#include "Relation.h"
#include "LinkedList.h"
#include <vector>


typedef unsigned ColumnID;
