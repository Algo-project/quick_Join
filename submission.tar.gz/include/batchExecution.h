#include <tbb/parallel_for_each.h>
#include <iostream>
#include <vector>
#include <stdio.h>
#include "Query.h"

std::vector<Result> batchQueryQxecution(std::vector<Query> v);
